CREATE TABLE "hug_counts" (
	"visitor_id" text PRIMARY KEY,
	"count" integer DEFAULT 0 NOT NULL
);
